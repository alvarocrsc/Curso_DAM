package Ejercicio_3;

public enum Categoria {
    ALTA_GAMA, MEDIA_GAMA, BAJA_GAMA;
}
