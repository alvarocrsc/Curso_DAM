package Ejercicio_4;

public enum Turno {
    MANANA, TARDE, NOCHE;
}
