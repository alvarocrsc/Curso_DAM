package Ejercicio_1;

public enum Traccion {
    CUATROPORDOS, CUATROPORCUATRO;
}
