package Ejercicio_1;

public enum Combustible {
    GASOLINA, DIESEL, HIBRIDO, ELECTRICO;
}
