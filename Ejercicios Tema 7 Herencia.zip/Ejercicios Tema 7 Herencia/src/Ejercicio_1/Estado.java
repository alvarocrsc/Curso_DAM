package Ejercicio_1;

public enum Estado {
    DISPONIBLE,ALQUILADO,MANTENIMIENTO;
}
