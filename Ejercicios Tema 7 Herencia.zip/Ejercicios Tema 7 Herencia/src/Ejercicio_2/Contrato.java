package Ejercicio_2;

public enum Contrato {
    TIEMPO_COMPLETO, MEDIO_TIEMPO;
}
