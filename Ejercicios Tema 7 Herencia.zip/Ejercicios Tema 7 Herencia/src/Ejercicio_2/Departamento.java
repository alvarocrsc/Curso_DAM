package Ejercicio_2;

public enum Departamento {
    FINANZAS, IT, RECURSOSHUMANOS, LOGISTICA;
}
