package Ejercicio_5;

public enum Tipo {
    INDIVIDUAL, DOBLE, SUITE;
}
