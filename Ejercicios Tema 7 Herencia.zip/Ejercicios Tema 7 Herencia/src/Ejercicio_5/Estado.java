package Ejercicio_5;

public enum Estado {
    DISPONIBLE, RESERVADA, OCUPADA;
}
