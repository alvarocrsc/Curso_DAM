package Ejercicio_6;

public enum Categoria {
    CIENCIA, LITERATURA, HISTORIA, FILOSOFIA;
}
