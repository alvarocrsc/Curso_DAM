import java.util.Arrays;

public class StudentGroup {
    private Student[] studentGroup = new Student[5];

    public StudentGroup() {
    }

    public StudentGroup(Student student) {
        this.studentGroup[0] = student;
    }

    public void insertStudent(Student student) {
        for (int i = 0; i < studentGroup.length; i++) {
            if (studentGroup[i] != null) {
                studentGroup.
            }
        }
    }
}
