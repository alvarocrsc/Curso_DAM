public class Student {
    private String name;
    private int age, classroom, grade;

    public Student(String name, int age, int classroom, int grade) {
        this.name = name;
        this.age = age;
        this.classroom = classroom;
        this.grade = grade;
    }
}
