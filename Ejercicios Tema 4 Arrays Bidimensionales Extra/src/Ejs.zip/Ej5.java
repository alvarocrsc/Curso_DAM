public class Ej5 {
    public static void main(String[] args) {

    }
}
